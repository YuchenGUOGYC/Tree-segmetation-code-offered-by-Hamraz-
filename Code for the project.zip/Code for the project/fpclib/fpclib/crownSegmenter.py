# Author: Hamid Hamraz (hhamraz@cs.uky.edu)
# 2016, Department of Computer Science, University of Kentucky

import numpy
from operator import itemgetter

from constants import *
import geometry as gm
import util
import forest

MIN_ANGLE = 32.7
ALPHA_NS = 1./3.
BETA_NS = 0.7

MAX_ANGLE = 85.0
MAX_SLOPE = math.tan(math.radians(MAX_ANGLE))
ALPHA_S = 2./3.
BETA_S = 0.85

def smoothenGridDSM(grid, radius):
	row_num = len(grid)
	col_num = len(grid[0])
	def averageNeighbors(r, c, dim):
		sum = 0.0
		count = 0
		start_r = max(0, r-radius)
		start_c = max(0, c-radius)
		end_r = min(row_num-1, r+radius)
		end_c = min(col_num-1, c+radius)
		for i in range(start_r, end_r+1):
			for j in range(start_c, end_c+1):
				if grid[i][j] == None: continue
				sum += grid[i][j][START][dim]
				count += 1
		return sum/count
	for i in range(row_num):
		for j in range(col_num):
			if grid[i][j] == None: continue
			grid[i][j][START].append(averageNeighbors(i, j, Z))
			grid[i][j][START].append(averageNeighbors(i, j, VEG_H))
	def triangularSmooth(dim):
		smooth_grid = []
		for i in range(row_num):
			row = [None] * col_num
			for j in range(col_num):
				if grid[i][j] == None: continue
				row[j] = averageNeighbors(i, j, dim)
			smooth_grid.append(row)
		for i in range(row_num):
			for j in range(col_num):
				if grid[i][j] == None: continue
				grid[i][j][START][dim] = smooth_grid[i][j]
	for i in range(TRIANGULAR_SMOOTHING_CYCLES-1):
		triangularSmooth(SMZ)
		triangularSmooth(SM_VEG_H)
				

def cutDirectedSlice(grid, c_loc, slice_width, angle, half=False):
	slice_width_cell_num = int(math.ceil(slice_width/EM_CELL_WIDTH))
	pixels = gm.generateLinePixels((c_loc[1], c_loc[0]), angle, MAX_CROWN_WIDTH_CELL_NUM, slice_width_cell_num, half)
	points = []
	rowNum, colNum = len(grid), len(grid[0])
	for j, i in pixels:
		if i >= rowNum or j >= colNum or i < 0 or j < 0: continue
		pts = grid[i][j]
		if pts != None: points.append(pts[START])
	center = grid[c_loc[0]][c_loc[1]][START]
	c = gm.rotatedCoordinatePt_Deg(center[X], center[Y], angle)
	p1 = gm.rotatedCoordinatePt_Deg(c[X], c[Y]-slice_width/2.0, -angle)
	p2 = gm.rotatedCoordinatePt_Deg(c[X], c[Y]+slice_width/2.0, -angle)
	return gm.pointsLieOnStripe(points, angle, p1, p2)

def isAReasonableTree(t_cell_num, t_height, cvxh, diams):
	if t_cell_num < MINIMUM_TREE_DSM_POINTS: return False
	if t_height < MINIMUM_TREE_HEIGHT: return False
	if numpy.median(diams) < MINIMUM_DETECTABLE_CROWN_WIDTH: return False
	if 2 * EM_CELL_WIDTH * (cvxh.area/math.pi)**0.5 < MINIMUM_DETECTABLE_CROWN_WIDTH + 2*VICINITY_INCLUSION_GUARD_BAND: return False
	return True

def clipOffClassifieds(slc, cIdx):
	l = len(slc)
	i = cIdx + 1
	while i<l and not slc[i][END]: i += 1
	rIdx = i-1
	i = cIdx - 1
	while i >= 0 and not slc[i][END]: i -= 1
	lIdx = i + 1
	return lIdx, rIdx


def clipFromGaps_indexes(slc, cIdx):
	sLen = len(slc)
	if sLen <= 5: return 0, sLen-1 
	sqrDisArray = []
	for i in range(sLen-1): sqrDisArray.append((slc[i+1][X] - slc[i][X])**0.5)
	smallsIdxes, bigsIdxes = util.findOutliers(sqrDisArray, 6.0)
	leftIdxes = []
	rightIdxes = []
	for idx in bigsIdxes:
		if idx < cIdx: leftIdxes.append(idx)
		else: rightIdxes.append(idx)
	lIdx = 0
	if len(leftIdxes) > 0: lIdx = max(leftIdxes) + 1
	rIdx = sLen - 1
	if len(rightIdxes) > 0: rIdx = min(rightIdxes)
	return lIdx, rIdx

def getWindowIdxToRight(seg, seedIdx, radius, dim):
	max = seg[seedIdx][dim] + radius
	maxIdx = seedIdx
	while maxIdx < len(seg) and seg[maxIdx][dim] <= max: maxIdx += 1
	return  maxIdx-1

def getWindowIdxToLeft(seg, seedIdx, radius, dim):
	min = seg[seedIdx][dim] - radius
	minIdx = seedIdx
	while minIdx >= 0 and seg[minIdx][dim] >= min: minIdx -= 1
	return minIdx + 1

def probeRightwardMinimumToBeBorder(seg, min, angles, insensitivity, cmflg_sense=False):
	def adaptiveWindow(angle, vegH):
		ang = math.degrees(angle)
		if ang < MIN_ANGLE: ang = MIN_ANGLE
		elif ang > MAX_ANGLE: ang = MAX_ANGLE
		w_s = ALPHA_S*BETA_S*vegH/MAX_SLOPE
		w_ns = ALPHA_NS*BETA_NS*0.5*vegH
		coef = (MAX_ANGLE-ang)/(MAX_ANGLE-MIN_ANGLE)
		return max(MINIMUM_DETECTABLE_CROWN_WIDTH/2.0, coef*w_ns + (1.-coef)*w_s)
	lAng = numpy.median(angles[0:min])	
	if lAng > 0: return False, START
	roughVegH = (seg[min][SM_VEG_H]+seg[START][SM_VEG_H])/2.0
	rw = 2 * insensitivity* adaptiveWindow(math.pi/2., roughVegH) 
	rightEnd = getWindowIdxToRight(seg, min, rw, X)
	if rightEnd == min: rightEnd += 1
	rAng_mag = numpy.median(numpy.absolute(angles[min:rightEnd]))
	rw = insensitivity* adaptiveWindow(rAng_mag, roughVegH)
	rightEnd = getWindowIdxToRight(seg, min, rw, X)
	if rightEnd == min: rightEnd += 1
	rAng = numpy.median(angles[min:rightEnd])	
	if not cmflg_sense:
		if rAng < 0.: return False, END
	else:
		if rAng <= lAng: return False, END
	return True, rightEnd

def refinedLocalMinimumBorder(seg, min, rEnd, angles):
	if rEnd - min == 1: return min
	sIdx = max(START, min-5)
	lms = []
	likelihood = []
	for i in range(min, rEnd-1):
		if seg[i-1][SMZ] >= seg[i][SMZ] and seg[i][SMZ] <= seg[i+1][SMZ]:
			lAng = numpy.median(angles[sIdx:i])
			if lAng>0: continue
			rAng = numpy.median(angles[i:rEnd])
			if rAng<0.: continue
			lms.append(i)
			likelihood.append(rAng-lAng)
	if len(lms) == 0: 
		return min
	maxIdx = 0
	for i in range(1, len(lms)):
		if likelihood[i] > likelihood[maxIdx]: maxIdx = i
	return lms[maxIdx]

def findRealLocalMinimumForward(seg, insensitivity):
	angles= []
	for i in range(len(seg)-1):
		p1, p2 = seg[i], seg[i+1]
		angles.append(math.atan2(p2[SMZ]-p1[SMZ], p2[X] - p1[X]))
	sIdx = getWindowIdxToRight(seg, 0, MINIMUM_DETECTABLE_CROWN_WIDTH*insensitivity/2.0, X) + 1
	eIdx = getWindowIdxToLeft(seg, len(seg)-1, MINIMUM_DETECTABLE_CROWN_WIDTH*insensitivity/2.0, X) - 1
	for i in range(sIdx, eIdx+1):
		if seg[i-1][SMZ] >= seg[i][SMZ] and seg[i][SMZ] <= seg[i+1][SMZ]:
			probe, rIdx = probeRightwardMinimumToBeBorder(seg, i, angles, insensitivity)
			if probe: 
				if rIdx >= len(seg)-1: return rIdx
				return refinedLocalMinimumBorder(seg, i, rIdx, angles) - 1
	return len(seg)-1

def findRealLocalMinimumBackward(seg, insensitivity):
	reversedSeg = []
	for p in reversed(seg):
		p[X] = -p[X]
		reversedSeg.append(p)
	lIdx = len(seg) - 1 - findRealLocalMinimumForward(reversedSeg, insensitivity)
	for p in seg: p[X] = -p[X]
	return lIdx

def detectHighestTreeProfile(slc, insensitivity, remove_gaps):
	def maximumExcSet(elmnt):
		""" finds the maximum among all those elements
		that does not have the corresponding True value appended to them"""
		l = len(slc)
		maxIdx = 0
		while maxIdx < l and slc[maxIdx][END]: maxIdx += 1
		for i in range(maxIdx+1, l):
			if not slc[i][END]:
				if slc[i][elmnt] > slc[maxIdx][elmnt]:
					maxIdx = i
		return maxIdx
	cIdx = maximumExcSet(SMZ)
	lIdx, rIdx = clipOffClassifieds(slc, cIdx)
	if remove_gaps:
		lOffset, rOffset = clipFromGaps_indexes(slc[lIdx:rIdx+1], cIdx-lIdx)
		rIdx = lIdx + rOffset
		lIdx += lOffset
	rOffset = findRealLocalMinimumForward(slc[cIdx:rIdx+1], insensitivity)
	lOffset = findRealLocalMinimumBackward(slc[lIdx: cIdx + 1], insensitivity)
	return lIdx+lOffset, cIdx+rOffset

def segmentPortions(trees, slice_width = DIRECTIONAL_SLICE_WIDTH, insensitivity=1.0, fixSmooth=False, remove_gaps=True):
	resultTrees, noise = [], []
	for t in trees:
		points = forest.extractPointCloud(t, only_surface=True)
		if fixSmooth:
			for p in points: del(p[SMZ:])
			smoothenGridDSM(t, CELL_RESOLUTION)
		points.sort(key = itemgetter(SMZ), reverse = True)
		for p in points: p.append(False)
		seg_result = segmentPortion(t, points, slice_width, insensitivity, remove_gaps)
		resultTrees.extend(seg_result[0])
		noise.extend(seg_result[1])
		for p in points: p.pop()
	return resultTrees, noise

def segmentPortion(portion, sorted_points, slice_width, insensitivity, remove_gaps):
	cct = 0
	resultTrees, noise  = [], []
	peak_idx = 0
	while cct < len(sorted_points):
		while sorted_points[peak_idx][END]: peak_idx += 1
		peak_loc = sorted_points[peak_idx][GRID_LOCATION]
		borderPts = []
		diams = []
		maxDiam = -1.0
		angles = [0.0, 90.0, 45.0, 135.0]
		doneAngles = []
		delta_ang  = 22.5
		while  delta_ang >= MINIMUM_SLICING_ANGLE  :
			for ang in angles:
				bps, d = findBorderPoints(portion, peak_loc, ang, slice_width, insensitivity, remove_gaps)
				borderPts.extend(bps)
				if d > maxDiam: maxDiam = d
				diams.append(d)
			doneAngles.extend(angles)
			alpha = 2 * math.acos(maxDiam/2.0 / (maxDiam/2.0 + VICINITY_INCLUSION_GUARD_BAND)) * 180.0 / math.pi
			if 4*delta_ang <= alpha/2: break
			angles = numpy.array(doneAngles) + delta_ang
			delta_ang /= 2.0
		cvxh = gm.Polygon(gm.convex_hull(borderPts))
		tree_cells = []
		apex = portion[peak_loc[0]][peak_loc[1]][START]
		if maxDiam == 0:
			apex[END] = True
			tree_cells.append(peak_loc)
		else:
			point_coordinates = gm.cellsEncompassedByPolygon(cvxh)
			for i, j in point_coordinates: 
				if portion[i][j] != None and not portion[i][j][START][END]:
					tree_cells.append((i,j))
					portion[i][j][START][END] = True
		cct += len(tree_cells)
		if isAReasonableTree(len(tree_cells), apex[SM_VEG_H], cvxh, diams): resultTrees.append(tree_cells)
		else: noise.append(tree_cells)
	return resultTrees, noise

def findBorderPoints(portion,  peak_loc, ang, slice_width, insensitivity, remove_gaps):
	slc = cutDirectedSlice(portion, peak_loc, slice_width, ang)
	gm.rotateCoordSys(slc, ang)
	slc.sort(key = itemgetter(X))
	lIdx, rIdx = detectHighestTreeProfile(slc, insensitivity, remove_gaps)
	lp, rp = slc[lIdx], slc[rIdx]
	diam = rp[X] - lp[X]
	row_guard_band = int(VICINITY_INCLUSION_GUARD_BAND/EM_CELL_WIDTH * math.sin(math.radians(ang)))
	col_guard_band = int(VICINITY_INCLUSION_GUARD_BAND/EM_CELL_WIDTH * math.cos(math.radians(ang)))
	bp1 = lp[GRID_LOCATION][0] - row_guard_band, lp[GRID_LOCATION][1] - col_guard_band
	bp2 = rp[GRID_LOCATION][0] + row_guard_band, rp[GRID_LOCATION][1] + col_guard_band
	gm.rotateCoordSys(slc, -ang)
	return [bp1, bp2], diam

def segmentCanopy(grid, multilayer=0, merge=False):
	smoothenGridDSM(grid, CELL_RESOLUTION)
	# if segmentation is without layering the canopy.
	if multilayer == 0: 
		seg_result = segmentPortions([grid], insensitivity=1.0)
		return forest.getPointClouds(grid, seg_result[0]), forest.getPointClouds(grid, seg_result[1])
	# If segmentation is using the regional layering method.
	elif multilayer == 1:
		subcanopies = segmentPortions([grid], insensitivity=3.0)[0]
		trees, noise = [], []
		for sc in subcanopies:
			sc_g = cutTreeGrid(sc, grid)
			seg_res = segmentLayeredCanopy(sc_g, True, -1, merge)
			trees.extend(seg_res[0])
			noise.extend(seg_res[1])
		return trees, noise
	# If layering is using the local layering method.
	elif multilayer == 2:
		return segmentLayeredCanopy(grid, False, 6.0, merge)
	else:
		print "Unrecognized canopy layering method."
		exit()


def cutTreeGrid(t, g):
	min_r, max_r = min(t, key=itemgetter(0))[0] - MARGIN_TO_BORDER_CELL_NUM, max(t, key=itemgetter(0))[0] + MARGIN_TO_BORDER_CELL_NUM
	min_c, max_c = min(t, key=itemgetter(1))[1] - MARGIN_TO_BORDER_CELL_NUM, max(t, key=itemgetter(1))[1] + MARGIN_TO_BORDER_CELL_NUM
	row_num = max_r-min_r+1
	col_num = max_c-min_c+1
	tg = [None] * row_num
	for i in range(row_num): tg[i] = [None] * col_num
	for i, j in t:
		n_i, n_j = i-min_r, j-min_c
		tg[n_i][n_j] = g[i][j]
		for p in tg[n_i][n_j]:
			p[GRID_LOCATION] = (n_i, n_j)
	return tg

def getConvexPolygons(trees):
	pgs = []
	for t in trees:
		cvxh = gm.convexHull(t, X, Y)
		pgs.append(gm.Polygon(cvxh))
	return pgs

def segmentLayeredCanopy(grid, is_global, radius, merge):
	h_trees, noise = [], []
	overstory, nct, optd, ovh, ovt, understory, rct, uptd, undh, undt, density, height, thickness = forest.layerCanopyGrid(grid, VEG_H, is_global, radius)
	tree_coords, noise_coords = segmentPortions([overstory])
	h_trees.extend(forest.getPointClouds(overstory, tree_coords))
	noise.extend(forest.getPointClouds(overstory, noise_coords))
	layers = [h_trees]
	while rct > MINIMUM_TREE_DSM_POINTS:
		overstory, nct, optd, ovh, ovt, understory, rct, uptd, undh, undt, density, height, thickness       = forest.layerCanopyGrid(understory, VEG_H, is_global, radius)
		if optd == 0.0: break
		tree_coords, noise_coords = segmentPortions([overstory], fixSmooth=True)
		lyr_trees =  forest.getPointClouds(overstory, tree_coords)
		h_trees.extend(lyr_trees)
		noise.extend(forest.getPointClouds(overstory, noise_coords))
		layers.append(lyr_trees)
	if merge:
		pieces = layers.pop()
		pieces_hulls = getConvexPolygons(pieces)
		while len(layers) > 0:
			h_ts = layers.pop()
			hls = getConvexPolygons(h_ts)
			mergeLayers(h_ts, hls, pieces, pieces_hulls)
			pieces, pieces_hulls = h_ts, hls
		h_trees, hulls = pieces, pieces_hulls
	return h_trees, noise

def mergeLayers(trees, hulls, pieces, p_hulls):
	def isAdjacent(c1, h1, c2, h2):
		pcd_min = min(len(c1)/h1.area, len(c2)/h2.area)
		ips_max = pcd_min**-.5
		if h1.distance(h2) > 2.*ips_max: return False
		intersect = h1.intersection(h2)
		if intersect.area > 0: return False
		return True
	for i in range(len(trees)):
		adj_idxs = []
		for j in range(len(pieces)):
			if isAdjacent(trees[i], hulls[i], pieces[j], p_hulls[j]): adj_idxs.append(j)
		if len(adj_idxs) == 0: continue
		tree, hull, merged_idxs = mergeTree(trees[i], hulls[i], pieces, p_hulls, adj_idxs) 
		trees[i], hulls[i] = tree, hull
	trees.extend(pieces)
	hulls.extend(p_hulls)

def mergeTree(tree, hull, pcs, phs, adj_idxs):
	min_den = len(tree)/hull.area
	cld = list(tree)
	for i in adj_idxs: 
		den = len(pcs[i])/phs[i].area
		if den < min_den: min_den = den
		cld.extend(pcs[i])
	grid = forest.indexPointCloud(cld, calc_veg_h=False)
	probe_segmentation = segmentPortions([grid], slice_width=max(1.5*min_den**-.5, DIRECTIONAL_SLICE_WIDTH), fixSmooth=True, remove_gaps=True)
	probe_segs = forest.getPointClouds(grid, probe_segmentation[0])
	if len(probe_segs) == 0: return tree, hull, []
	probe_hulls = getConvexPolygons(probe_segs)
	max_idx = 0
	max_area = hull.intersection(probe_hulls[0]).area
	for i in range(1, len(probe_hulls)):
		a = hull.intersection(probe_hulls[i]).area
		if a > max_area:
			max_idx = i
			max_area = a
	hl = probe_hulls[max_idx]
	merged_idxs = []
	for i in adj_idxs:
		if hl.intersection(phs[i]).area >= phs[i].area/2.:
			merged_idxs.append(i)			
	tree = list(tree)
	hull = list(hull.exterior.coords)
	for i in reversed(merged_idxs): 
		tree.extend(pcs.pop(i))
		hull.extend(phs.pop(i).exterior.coords)
	hull = gm.Polygon(gm.convexHull(hull, X, Y))
	return tree, hull, merged_idxs

