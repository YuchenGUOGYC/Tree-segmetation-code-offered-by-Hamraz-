# Author: Hamid Hamraz (hhamraz@cs.uky.edu)
# 2016, Department of Computer Science, University of Kentucky

import numpy
from operator import itemgetter

from constants import *
import geometry as gm
def printBasicStats(d):
	ptNum = len(d)
	gr1c = gr2c = unassc = lvc = mvc = hvc = noc = 0
	for r in d:
		cl = r[CLASS]
		if cl == HIGH_VEG: hvc += 1
		elif cl == MED_VEG: mvc +=1
		elif cl == LOW_VEG: lvc += 1
		elif cl == GROUND1: gr1c += 1
		elif cl == GROUND2: gr2c += 1
		elif cl == UNASSIGNED: unassc += 1
		elif cl == NOISE: noc += 1
		else: print "Unrecognized Class:", cl
	print "High Veg:\t", hvc, '\t', 100.0 *hvc /ptNum, '%'
	print "Medium Veg:\t", mvc, '\t', 100.0 *mvc /ptNum, '%'
	print "Low Veg:\t", lvc, '\t', 100.0 *lvc /ptNum, '%'
	print "ground 1:\t", gr1c, '\t', 100.0 *gr1c /ptNum, '%'
	print "Ground 2:\t", gr2c, '\t', 100.0 *gr2c /ptNum, '%'
	print "Unassigned:\t", unassc, '\t', 100.0 *unassc /ptNum, '%'
	print "Noise:\t", noc, '\t', 100.0 *noc /ptNum, '%'


def extractBorders(d):
	""" Takes a list of LiDAR points.
	 Returns 4 coordinates representing a box encompassing the points.  """
	minX = min(d, key=itemgetter(X))[X] - MARGIN_TO_BORDER
	minY = min(d, key=itemgetter(Y))[Y] - MARGIN_TO_BORDER
	maxX = max(d, key=itemgetter(X))[X] + MARGIN_TO_BORDER
	maxY = max(d, key=itemgetter(Y))[Y] + MARGIN_TO_BORDER
	return minX, minY, maxX, maxY

def extractPointCloud(grid, row_start = 0, row_end = -1, col_start = 0, col_end = -1, only_surface=False):
	if row_start < 0: row_start = 0
	if col_start < 0: col_start = 0
	if row_end == -1 or row_end > len(grid): row_end = len(grid)
	if col_end == -1 or col_end > len(grid[0]): col_end = len(grid[0])
	points = []
	if only_surface:
		for i in range(row_start, row_end):
			for j in range(col_start, col_end):
				if grid[i][j] == None: continue
				points.append(grid[i][j][START])
	else:
		for i in range(row_start, row_end):
			for j in range(col_start, col_end):
				if grid[i][j] == None: continue
				points.extend(grid[i][j])
	return points

def getPointClouds(grid, treesCoordinates, surface=False):
	trees = []
	for tcs in treesCoordinates:
		trees.append(getPointCloud(grid, tcs, surface))
	return trees

def getPointCloud(grid, coords, surface=False):
	points = []
	if surface:
		for i, j in coords: points.append(grid[i][j][START])
	else:
		for i, j in coords: points.extend(grid[i][j])
	return points

def gridData(d, minX, minY, maxX, maxY, cw):
	clmnNum = int(math.ceil((maxX - minX)/cw))
	rowNum = int(math.ceil((maxY - minY)/cw))
	grid = [None] * rowNum
	for i in range(rowNum): grid[i] = [None] * clmnNum
	for i in range(rowNum):
		for j in range(clmnNum):
			grid[i][j] = []
	for p in d:
		xp = p[X] - minX
		yp = p[Y] - minY
		xp = int(xp/cw)
		yp = int(yp/cw)
		grid[yp][xp].append(p)
	return grid


def indexPointCloud(cld, calc_veg_h=True):
	minX, minY, maxX, maxY = extractBorders(cld)
	grd = gridData(cld, minX, minY, maxX, maxY, EM_CELL_WIDTH)
	row_num = len(grd)
	col_num = len(grd[0])
	for i in range(row_num):
		for j in range(col_num):
			if len(grd[i][j]) == 0: grd[i][j] = None
			else: grd[i][j].sort(key=itemgetter(Z), reverse=True)
	if not calc_veg_h:
		for i in range(row_num):
			for j in range(col_num):
				if grd[i][j] == None: continue
				loc = (i, j)
				for p in grd[i][j]:
					del(p[GRID_LOCATION:])
					p.append(loc)
		return grd
	def groundElevations(i1, i2, j1, j2):
		elevations = []
		for i in range(i1, i2+1):
			for j in range(j1, j2+1):
				if grd[i][j] == None: continue
				pt_cl = grd[i][j][END][CLASS]
				if pt_cl != GROUND1 and pt_cl != GROUND2: continue
				elevations.append(grd[i][j][END][Z])
		return elevations
	def calculateGroundElevation(r, c):
		g_elvs = []
		rs, re = max(0, r-CELL_RESOLUTION), min(row_num-1, r+CELL_RESOLUTION)
		cs, ce = max(0, c-CELL_RESOLUTION), min(col_num-1, c + CELL_RESOLUTION)
		g_elvs.extend(groundElevations(rs, re, cs, ce))
		rs0, re0, cs0, ce0 = rs, re, cs, ce
		while len(g_elvs) == 0:
			rs, re = max(0, rs0-CELL_RESOLUTION), min(row_num-1, re0+CELL_RESOLUTION)
			cs, ce = max(0, cs0-CELL_RESOLUTION), min(col_num-1, ce0+CELL_RESOLUTION)
			g_elvs.extend(groundElevations(rs, rs0-1, cs, ce))
			g_elvs.extend(groundElevations(re0+1, re, cs, ce))
			g_elvs.extend(groundElevations(rs0, re0, cs, cs0-1))
			g_elvs.extend(groundElevations(rs0, re0, ce0+1, ce))
			rs0, re0, cs0, ce0 = rs, re, cs, ce
		return numpy.median(g_elvs)
	for i in range(row_num):
		for j in range(col_num):
			if grd[i][j] == None: continue
			g_e = calculateGroundElevation(i, j)
			for p in grd[i][j]: 
				p.append(max(0.0, p[Z] - g_e))
				p.append((i, j))
	return grd

def measureConvexPointDensity(g):
	pts = extractPointCloud(g)
	cvxh = gm.convexHull(pts, X, Y)
	poly = gm.Polygon(cvxh)
	return float(len(pts)) / poly.area

def excludeLowPoints(grid):
	low_pts = []
	for i in range(len(grid)):
		for j in range(len(grid[i])):
			if grid[i][j] == None: continue
			new_cell = []
			for p in grid[i][j]:
				if  p[CLASS] == GROUND1 or p[CLASS] == GROUND2 or p[VEG_H] < LOW_HEIGHT_THRESHOLD: low_pts.append(p)
				else: new_cell.append(p)
			if len(new_cell) > 0: grid[i][j] = new_cell
			else: grid[i][j] = None
	return low_pts

def excludeNonFirstReturnSurfaces(grid):
	non_firstreturn_cells = []
	for i in range(len(grid)):
		for j in range(len(grid[i])):
			if grid[i][j] == None: continue
			if grid[i][j][START][RETURN] != 1: 
				non_firstreturn_cells.append(grid[i][j])
				grid[i][j] = None
	return non_firstreturn_cells


def findHistogramTrough(neighbors, dim, smooth_round, smooth_window):
	elevations = []
	for p in neighbors: elevations.append(p[dim])
	start = min(elevations) - VERTICAL_NOMINAL_POST_SPACING*1.5
	end = max(elevations) + VERTICAL_NOMINAL_POST_SPACING*1.5
	residu = VERTICAL_NOMINAL_POST_SPACING - (end-start) % VERTICAL_NOMINAL_POST_SPACING
	end += residu
	smoothing_margin = smooth_window/2 * smooth_round * VERTICAL_NOMINAL_POST_SPACING
	start -= smoothing_margin
	end += smoothing_margin
	hist = [0] * int((end-start)/VERTICAL_NOMINAL_POST_SPACING)
	for h in elevations: hist[int((h-start)/VERTICAL_NOMINAL_POST_SPACING)] += 1
	unsmoothed = hist[smooth_window/2*smooth_round:len(hist)-smooth_window/2*smooth_round]
	for i in range(smooth_round): 
		hist = gm.rectangleSmooth(hist, smooth_window)
	start += smoothing_margin
	end -= smoothing_margin
	first_neg = 1
	for i in range(len(hist)-3, 1, -1):
		if gm.calcCurvature(hist, i, VERTICAL_NOMINAL_POST_SPACING) < 0.0:
			first_neg = i
			break
	first_pos = 1
	for i in range(first_neg-1, 1, -1):
		if gm.calcCurvature(hist, i, VERTICAL_NOMINAL_POST_SPACING) >= 0.0:
			first_pos = i
			break
	second_neg = 1
	for i in range(first_pos-1, 1, -1):
		if gm.calcCurvature(hist, i, VERTICAL_NOMINAL_POST_SPACING) < 0.0:
			second_neg = i
			break
	if second_neg == 1: thresh = start
	else: 
		thresh = (start+first_pos*VERTICAL_NOMINAL_POST_SPACING + start+second_neg*VERTICAL_NOMINAL_POST_SPACING) / 2 + VERTICAL_NOMINAL_POST_SPACING/2
	ovs = start+first_pos*VERTICAL_NOMINAL_POST_SPACING, start+first_neg*VERTICAL_NOMINAL_POST_SPACING
	unds = start + VERTICAL_NOMINAL_POST_SPACING*1.5, start+second_neg*VERTICAL_NOMINAL_POST_SPACING
	return ovs, thresh, unds

def layerCanopyGrid(g, dim, is_global, radius=None):
	row_num = len(g)
	col_num = len(g[0])
	g_new, g_rem = [], []
	for i in range(row_num): 
		g_new.append([None] * col_num)
		g_rem.append([None] * col_num)
	new_cell_ct = 0
	rem_cell_ct = 0
	overstory_thicknesses, overstory_heights  = [], []
	understory_thicknesses, understory_heights = [], []
	canopy_thicknesses, canopy_heights = [], []
	if is_global:
		vicinity = extractPointCloud(g)
		ovs, threshold, unds = findHistogramTrough(vicinity, dim, 3, HEIGHT_HISTOGRAM_SMOOTHING_WINDOW)
		overstory_thicknesses.append(ovs[1]-ovs[0])
		overstory_heights.append(ovs[0])
		understory_thicknesses.append(unds[1]-unds[0])
		understory_heights.append(unds[0])
		canopy_thicknesses.append(ovs[1]-unds[0])
		canopy_heights.append(unds[0])
		for i, row in enumerate(g):
			for j, cell in enumerate(row):
				if cell == None: continue
				thresh_idx = 0
				while thresh_idx < len(cell) and cell[thresh_idx][dim] > threshold: thresh_idx += 1
				g_new[i][j] = cell[:thresh_idx]
				if len(g_new[i][j]) == 0: g_new[i][j] = None
				else: new_cell_ct += 1
				g_rem[i][j] = cell[thresh_idx:]
				if len(g_rem[i][j]) == 0: g_rem[i][j] = None
				else: rem_cell_ct += 1
	else:
		nps = 1. / measureConvexPointDensity(g)**0.5
		radius *= nps
		if radius < MINIMUM_DETECTABLE_CROWN_WIDTH: radius = MINIMUM_DETECTABLE_CROWN_WIDTH
		r_c_num = int(math.ceil(radius/NOMINAL_POST_SPACING*CELL_RESOLUTION))
		for i, row in enumerate(g):
			for j, cell in enumerate(row):
				if cell == None: continue
				vicinity = extractPointCloud(g, row_start =i-r_c_num, row_end=i+r_c_num+1, col_start = j-r_c_num, col_end = j+r_c_num+1)
				pt = cell[START]
				vicinity = [p for p in vicinity if gm.twoDDis(pt, p, X, Y) <= radius]
				ovs, threshold, unds = findHistogramTrough(vicinity, dim, 3, HEIGHT_HISTOGRAM_SMOOTHING_WINDOW)
				overstory_thicknesses.append(ovs[1]-ovs[0])
				overstory_heights.append(ovs[0])
				understory_thicknesses.append(unds[1]-unds[0])
				understory_heights.append(unds[0])
				canopy_thicknesses.append(ovs[1]-unds[0])
				canopy_heights.append(unds[0])
				thresh_idx = 0
				while thresh_idx < len(cell) and cell[thresh_idx][dim] > threshold: thresh_idx += 1
				g_new[i][j] = cell[:thresh_idx]
				if len(g_new[i][j]) == 0: g_new[i][j] = None
				else: new_cell_ct += 1
				g_rem[i][j] = cell[thresh_idx:]
				if len(g_rem[i][j]) == 0: g_rem[i][j] = None
				else: rem_cell_ct += 1
	if new_cell_ct > MINIMUM_TREE_DSM_POINTS: ptd_h = measureConvexPointDensity(g_new)
	else: ptd_h = 0.0
	if rem_cell_ct > MINIMUM_TREE_DSM_POINTS: ptd_l = measureConvexPointDensity(g_rem)
	else: ptd_l = 0.0
	all_ptd = measureConvexPointDensity(g)
	return g_new, new_cell_ct, ptd_h, numpy.mean(overstory_heights), numpy.mean(overstory_thicknesses), g_rem, rem_cell_ct, ptd_l, numpy.mean(understory_heights), numpy.mean(understory_thicknesses), all_ptd, numpy.mean(canopy_heights), numpy.mean(canopy_thicknesses)
