# Author: Hamid Hamraz (hhamraz@cs.uky.edu)
# 2016, Department of Computer Science, University of Kentucky

import math
from shapely.geometry import *
from constants import *

def oneDDis(p1, p2, dim):
	return abs(p1[dim] - p2[dim])

def twoDDis(p1, p2, dim1, dim2):
	side1 = p1[dim1] - p2[dim1]
	side2 = p1[dim2] - p2[dim2]
	return math.sqrt(side1**2 + side2**2)

def threeDDis(p1, p2):
	sideX = p1[X] - p2[X]
	sideY = p1[Y] - p2[Y]
	sideZ = p1[Z] - p2[Z]
	return math.sqrt(sideX**2 + sideY**2 + sideZ**2)


def rotatedCoordinatePoint(x, y, ang):
	cosine = math.cos(ang)
	sine = math.sin(ang)
	return x*cosine + y*sine, -x*sine + y*cosine

def rotatedCoordinatePt_Deg(x, y, ang):
	ang = ang*math.pi / 180
	return rotatedCoordinatePoint(x, y, ang)

def rotateDatapoints(data, ang, unit = 'd'):
	if unit == 'D': ang = ang * math.pi / 180.0
	elif not unit == 'R': print "Unrecognized unit for angle:", unit
	rotateCoordSys(data, -ang, 'R')

def rotateCoordSys(data, ang, unit = 'D'):
	if unit == 'D': ang = ang * math.pi / 180.0
	elif not unit == 'R': print "Unrecognized unit for angle:", unit
	cosine = math.cos(ang)
	sine = math.sin(ang)
	for p in data:
		x, y = p[X], p[Y]
		p[X], p[Y] = x*cosine + y*sine, -x*sine + y*cosine

def rotateCoordinateSystem(segData, ang, unit = 'D'):
	if unit == 'D': ang = ang * math.pi / 180.0
	elif not unit == 'R': print "Unrecognized unit for angle:", unit
	for t in segData:
		for p in t:
			p[X], p[Y] = rotatedCoordinatePoint(p[X], p[Y], ang)


def fitLine(x, y):
	line = polyfit(x, y, 1)	
	return line[0], line[1]

def convex_hull(points):
	"""Computes the convex hull of a set of 2D points.
	Input: an iterable sequence of (x, y) pairs representing the points.
	Output: a list of vertices of the convex hull in counter-clockwise order,
	 starting from the vertex with the lexicographically smallest coordinates.
	Implements Andrew's monotone chain algorithm. O(n log n) complexity. """
	# Sort the points lexicographically (tuples are compared lexicographically).
	# Remove duplicates to detect the case we have just one unique point.
	points = sorted(set(points))
	if len(points) <= 1:
		return points
	# 2D cross product of OA and OB vectors, i.e. z-component of their 3D cross product.
	# Returns a positive value, if OAB makes a counter-clockwise turn,
	# negative for clockwise turn, and zero if the points are collinear.
	def cross(o, a, b):
		return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
	# Build lower hull 
	lower = []
	for p in points:
		while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
			lower.pop()
		lower.append(p)
	# Build upper hull
	upper = []
	for p in reversed(points):
		while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
			upper.pop()
		upper.append(p)
	# Concatenation of the lower and upper hulls gives the convex hull.
	# Last point of each list is omitted because it is repeated at the beginning of the other list. 
	return lower[:-1] + upper[:-1]
 

def convexHull(d, dim1, dim2):
	points = list()
	for p in d:
		points.append((p[dim1], p[dim2]))
	return convex_hull(points)

def calculateDiameter(data):
	hull = convexHull(data, X, Y)
	return calculateHullDiameter(hull)

def calculateHullDiameter(hull):
	idx1 = idx2 = 0
	maxDis = 0.0
	for i in range(len(hull)-1):
		for j in range(i+1, len(hull)):
			dis = twoDDis(hull[i], hull[j], X, Y)
			if dis > maxDis:
				idx1 = i
				idx2 = j
				maxDis = dis
	return hull[idx1], hull[idx2]

def calculateMeanDiameter(data):
	if len(data) <= 1: return 0.0
	lds, sds = LongAndShortDiameterSizes(data)
	return (lds+sds)/2.0

def LongAndShortDiameterSizes(d):
	hull = convexHall(d, X, Y)
	return LongAndShortHullDiameterSizes(hull)
def LongAndShortHullDiameterSizes(hull):
	idx1 = idx2 = 0
	maxDis = 0.0
	for i in range(len(hull)-1):
		for j in range(i+1, len(hull)):
			dis = twoDDis(hull[i], hull[j], X, Y)
			if dis > maxDis:
				idx1 = i
				idx2 = j
				maxDis = dis
	p1, p2 = hull[idx1], hull[idx2]	
	if p1[X] == p2[X]: rotate = math.pi/2.
	else: rotate = math.atan((p2[Y]-p1[Y])/(p2[X]-p1[X]))
	hull_r = [[p[X], p[Y]] for p in hull]
	rotateCoordSys(hull_r, rotate, unit = 'R')
	poly = Polygon(hull_r)
	minx, miny, maxx, maxy = poly.bounds
	lds = maxx - minx
	sds = maxy - miny
	return lds, sds

def hullDiameterSize(hull):
	ds, de = calculateHullDiameter(hull)
	return twoDDis(ds, de, X, Y)

def diameterSize(data):
	ds, de = calculateDiameter(data)
	return twoDDis(ds, de, X, Y)


def getNeighbors(p, data, r):
	ns = []
	for pt in data:
		if threeDDis(p, pt) < r:
			ns.append(pt)
	return ns


def isBetweenInc(x, a, b):
	if a <= b: return a<=x and x<=b
	return b<=x and x<=a

def pointLieOnSeg(p, p1, p2):
	if p1[X] == p2[X]: return p[X] == p1[X] and isBetweenInc(p[Y], p1[Y], p2[Y])
	m = (p2[Y]-p1[Y]) / (p2[X]-p1[X])
	b = p1[Y] - m*p1[X]	
	return p[Y] == m*p[X] + b and isBetweenInc(p[X], p1[X], p2[X])


def boundingSquare(data):
	minX = 0
	minY = 0
	maxX = 0
	maxY = 0
	for i in range(1, len(data)):
		if data[i][X] < data[minX][X]: minX = i
		if data[i][Y] < data[minY][Y]: minY = i
		if data[i][X] > data[maxX][X]: maxX = i
		if data[i][Y] > data[maxY][Y]: maxY = i
	return minX, minY, maxX, maxY
		

def pointLieOnLeftBoxExc(p, p1, p2):
	if (p[X]==p1[X] and p[Y]==p1[Y]) or (p[X]==p2[X] and p[Y]==p2[Y]): return False
	if p1[Y] == p2[Y]: return False
	if not isBetweenInc(p[Y], p1[Y], p2[Y]): return False
	if p1[X] == p2[X]: return p[X] < p1[X]
	m = (p2[Y]-p1[Y]) / (p2[X]-p1[X])
	b = p1[Y] - m*p1[X]		
	x_seg = (p[Y] - b) / m
	if p[X] >= x_seg: return False
	return True
	
def pointLieOnRightBoxExc(p, p1, p2):
	if (p[X]==p1[X] and p[Y]==p1[Y]) or (p[X]==p2[X] and p[Y]==p2[Y]): return False
	if p1[Y] == p2[Y]: return False
	if not isBetweenInc(p[Y], p1[Y], p2[Y]): return False
	if p1[X] == p2[X]: return p[X] > p1[X]
	m = (p2[Y]-p1[Y]) / (p2[X]-p1[X])
	b = p1[Y] - m*p1[X]		
	x_seg = (p[Y] - b) / m
	if p[X] <= x_seg: return False
	return True
	
def convexHull_include(cvxh, pt):
	lcv = len(cvxh)
	if lcv == 0: return False
	if lcv == 1: return cvxh[START][X] == pt[X] and cvxh[START][Y] == pt[Y]
	if lcv == 2: return pointLieOnSeg(pt, cvxh[START], cvxh[END])
	minX, minY, maxX, maxY = boundingSquare(cvxh)
	if not isBetweenInc(pt[X], cvxh[minX][X], cvxh[maxX][X]): return False 
	if not isBetweenInc(pt[Y], cvxh[minY][Y], cvxh[maxY][Y]): return False  
	i = minY
	while not i == maxY:
		fp = cvxh[i]
		i = (i+1) % lcv
		np = cvxh[i]
		if pointLieOnRightBoxExc(pt, fp, np): return False
	while not i == minY:
		fp = cvxh[i]
		i = (i+1) % lcv
		np = cvxh[i]
		if pointLieOnLeftBoxExc(pt, fp, np): return False
	return True


def pointToTheLeftOrAboveLine(p, m, b):
	if m == 0: return p[Y] > b
	xl = (p[Y]-b) / m
	return p[X] < xl

def cutData(data, m, b):
	portion1 = []
	portion2 = []
	for i, p in enumerate(data):
		if pointToTheLeftOrAboveLine(p, m, b): portion1.append(i)
		else: portion2.append(i)
	return portion1, portion2

def cutConvexHull(hull, m, b):
	cond = pointToTheLeftOrAboveLine(hull[START], m, b)
	lcv = len(hull)
	i = 1
	while i < lcv and pointToTheLeftOrAboveLine(hull[i], m, b) == cond:
		i += 1
	portion1 = range(i)
	j = i+1
	while j < lcv and not pointToTheLeftOrAboveLine(hull[j], m, b) == cond:
		j += 1
	portion2 = range(i, j)
	portion1 = range(j, lcv) + portion1
	if not lcv == len(portion1) + len(portion2): print "Error in portioning of cutConvexHull!"
	return portion1, portion2


def distancePointToLine(p, p1, p2):
	if p1[Y] == p2[Y]: return abs(p[Y] - p1[Y])
	if p1[X] == p2[X]: return abs(p[X] - p1[X])
	m  = (p2[Y] - p1[Y]) / (p2[X] - p1[X])
	b = p1[Y] - m*p1[X]
	vm = -1.0/m
	vb = p[Y] - vm*p[X]
	x = (b - vb) / (vm - m)
	y = m*x + b
	return twoDDis(p, (x,y), X, Y)
	

def convexHull_area(cvxh):
	lcv = len(cvxh)
	if lcv <= 2: return 0
	if lcv == 3: return twoDDis(cvxh[0], cvxh[1], X, Y) * distancePointToLine(cvxh[2], cvxh[0], cvxh[1]) / 2.0
	c = (cvxh[START][X] + cvxh[lcv/2][X]) / 2.0, (cvxh[START][Y] + cvxh[lcv/2][Y]) / 2.0
	area = 0
	for i in range(lcv-1):
		area += twoDDis(cvxh[i], cvxh[i+1], X, Y) * distancePointToLine(c, cvxh[i], cvxh[i+1])
	area += twoDDis(cvxh[END], cvxh[START], X, Y) * distancePointToLine(c, cvxh[END], cvxh[START])
	return area / 2.0


def convexHull_perimeter(h):
	perim = 0.0
	ptNum = len(h)
	for i in range(ptNum-1):
		perim += twoDDis(h[i], h[i+1], X, Y)
	perim += twoDDis(h[END], h[START], X, Y)
	return perim

def boundingSquare_include(box, p):
	minX, minY, maxX, maxY = box
	return isBetweenInc(p[X], minX, maxX) and isBetweenInc(p[Y], minY, maxY)


def boundingBoxes_intersect(d1, d2):
	box = boundingSquare(d1)
	mnX1, mnY1, mxX1, mxY1 = d1[box[0]][X], d1[box[1]][Y],  d1[box[2]][X], d1[box[3]][Y]
	box = boundingSquare(d2)
	mnX2, mnY2, mxX2, mxY2 = d2[box[0]][X], d2[box[1]][Y], d2[box[2]][X], d2[box[3]][Y]
	if mnX1 > mxX2 or mnX2 > mxX1: return None
	if mnY1 > mxY2 or mnY2 > mxY1: return None
	minX = mnX1
	if mnX1 < mnX2: minX = mnX2
	maxX = mxX1
	if mxX1 > mxX2: maxX = mxX2
	minY = mnY1
	if mnY1 < mnY2: minY = mnY2
	maxY = mxY1
	if mxY1 > mxY2: maxY = mxY2
	return minX, minY, maxX, maxY



def intersect_convexHulls(h1, h2):
	box = boundingBoxes_intersect(h1, h2)
	if box == None: return []
	iPts1 = []
	for p in h1:
		if boundingSquare_include(box, p):
			iPts1.append(p)
	iPts2 = []
	for p in h2:
		if boundingSquare_include(box, p):
			iPts2.append(p)
	intersect = []
	for p in iPts1:
		if convexHull_include(h2, p):
			intersect.append(p)
	for p in iPts2:
		if convexHull_include(h1, p):
			intersect.append(p)
	return convex_hull(intersect)

def pointsLieOnStripe(data, ang, p1, p2):
	m = math.tan(math.radians(ang))
	slc = []
	if m== 0: 	
		for p in data:
			if isBetweenInc(p[Y], p1[Y], p2[Y]): slc.append(p)
		return slc
	v_m = -1.0/m
	b1 = p1[Y] - m*p1[X]
	b2 = p2[Y] - m*p2[X]
	for p in data:
		v_b = p[Y] - v_m*p[X]
		xPt1 = (v_b-b1)/(m-v_m), (v_m*b1-m*v_b)/(v_m-m)
		xPt2 = (v_b-b2)/(m-v_m), (v_m*b2-m*v_b)/(v_m-m)
		dis1 = twoDDis(p, xPt1, X, Y)
		dis2 = twoDDis(p, xPt2, X, Y)
		dis = twoDDis(xPt1, xPt2, X, Y)
		if dis1>dis or dis2>dis: continue
		slc.append(p)
	return slc

def lineInterceptLineSegment(p, m, p1, p2):
	if p1[X] == p2[X]:
		if abs(m) >= MAX_FLOAT_VALUE: return None
		else: mls = MAX_FLOAT_VALUE
	else:
		mls = (p2[Y]-p1[Y]) / (p2[X]-p1[X])
	print m, mls
	if m == mls: return None
	b = p[Y] - m*p[X]
	bls = p1[Y] - mls*p1[X]
	intercept_x = (bls-b)/(m-mls)
	iPt = intercept_x, m*intercept_x+b
	if isBetweenInc(intercept_x, p1[X], p2[X]): return iPt
	return None


def angleDifference_degrees(a1, a2):
	""" returns the magnitude of the acute angle between two angles
	 the angles should be in degrees. """
	a1 = a1 % 360.0
	a2 = a2 % 360.0
	diff = abs(a1-a2)
	if diff <= 180.0: return diff
	else: return 360.0-diff
	

def circularityFactor(cvxh):
	area = convexHull_area(cvxh)
	perimeter  = convexHull_perimeter(cvxh)
	return 4*math.pi*area / perimeter**2
	

def convexHull_embrace(h, d):
	includeSet = []
	for p in d:
		if convexHull_include(h, p):
			includeSet.append(p)
	return includeSet

def fitParabola(data, x_dim, y_dim):
	x = []
	y = []
	for p in data:
		x.append(p[x_dim])
		y.append(p[y_dim])
	return polyfit(x, y, 2)

def distanceToHull(hull, pt):
	return Point(pt).distance(Polygon(hull))

def hullIncludePoint(h, p):
	return distanceToHull(h, p) == 0.0


def polygonArea(poly_points):
	return Polygon(poly_points).area


def generateLinePixels(mid, ang, length, thickness, half):
	rad = math.radians(ang)
	sine = math.sin(rad)
	cosine = math.cos(rad)
	dx = int(length*cosine/2)
	dy = int(length*sine/2)
	if not half: return interpolatePixelsAlongLine(mid[0]-dx, mid[1]-dy, mid[0]+dx, mid[1]+dy, thickness)
	else: return interpolatePixelsAlongLine(mid[0], mid[1], mid[0]+dx, mid[1]+dy, thickness)


def eightConnectedComponents(i, j):
	return [(i-1, j-1), (i, j-1), (i+1, j-1), (i-1, j), (i+1, j), (i-1, j+1), (i, j+1), (i+1, j+1)]

def interpolatePixelsAlongLine(x0, y0, x1, y1, t):
	"""Uses Xiaolin Wu's line algorithm to interpolate all of the pixels along a
	straight line, given two points (x0, y0) and (x1, y1) 
	t is the thickness of the line. """
	x=[]
	y=[]
	dx = x1-x0
	dy = y1-y0
	steep = abs(dx) < abs(dy)
	if steep:
		x0,y0 = y0,x0
		x1,y1 = y1,x1
		dy,dx = dx,dy
	if x0 > x1:
		x0,x1 = x1,x0
		y0,y1 = y1,y0
	gradient = float(dy) / float(dx)  # slope
	tspan = int(0.5 * t * abs(dx) / (dx**2 + dy**2)**0.5) + 1 # the thickness span
	""" handle first endpoint """
	xend = round(x0)
	yend = y0 + gradient * (xend - x0)
	xpxl0 = int(xend)
	ypxl0 = int(yend)
	for i in range(-tspan, tspan+1):
		x.append(xpxl0)
		y.append(ypxl0 + i) 
	intery = yend + gradient
	""" handles the second point """
	xend = round (x1);
	yend = y1 + gradient * (xend - x1);
	xpxl1 = int(xend)
	ypxl1 = int (yend)
	for i in range(-tspan, tspan+1):
		x.append(xpxl1)
		y.append(ypxl1 + i) 
	""" main loop """
	for px in range(xpxl0 + 1 , xpxl1):
		for i in range(-tspan, tspan+1):
			x.append(px)
			y.append(int(intery) + i)
		intery = intery + gradient;
	if steep:
		y,x = x,y
	coords=zip(x,y)
	return coords


def convexHull_grid(g):
	rowNum = len(g)
	colNum = len(g[0])
	boundaries = []
	for i in range(rowNum):
		j = 0
		while j < colNum and g[i][j] == None: j += 1
		if j < colNum: boundaries.append((i,j))
		j = colNum - 1
		while j >= 0 and g[i][j] == None: j -= 1
		if j >= 0: boundaries.append((i,j))
	for j in range(colNum):
		i = 0
		while i<rowNum and g[i][j] == None: i += 1
		if i < rowNum: boundaries.append((i,j))
		i = rowNum - 1
		while i >= 0 and g[i][j] == None: i -=1
		if i >= 0: boundaries.append((i,j))
	return convex_hull(boundaries)

def polygonCircumferencePixels(points):
	bounds = {}
	for i in range(len(points)-1):
		coords = interpolatePixelsAlongLine(points[i][0], points[i][1], points[i+1][0], points[i+1][1])
		for p in coords:
			if p[0] in bounds:
				bnds = bounds[p[0]]
				if p[1] < bnds[0]: bnds[0] = p[1]
				elif p[1] > bnds[1]: bnds[1] = p[1]
			else:
				bounds[p[0]] = [p[1], p[1]]
	return bounds

def cellsEncompassedByPolygon(poly):
	#bounds = polygonCircumferencePixels(poly_points)
	#cells = []
	#for k in bounds:
	#	for j in range(bounds[k][0], bounds[k][1]+1):
	#		cells.append((k,j))
	start_x = int(poly.bounds[0])
	start_y = int(poly.bounds[1])
	end_x = int(math.ceil(poly.bounds[2]))
	end_y = int(math.ceil(poly.bounds[3]))
	cells = []
	for i in range(start_x, end_x+1):
		for j in range(start_y, end_y+1):
			if poly.distance(Point((i, j))) == 0:
				cells.append((i, j))
	return cells

def rectangleSmooth(x, w):
	y = []
	s = float(sum(x[:w]))
	y.append(s/w)
	for i in range(w/2+1, len(x)-w/2):
		s = s - x[i-w/2-1] + x[i+w/2]
		y.append(s/w)
	return y


def calcCurvature(y, idx, h):
	return (y[idx-2] + y[idx-1] - 4*y[idx] + y[idx+1] + y[idx+2]) / (5 * h**2)

