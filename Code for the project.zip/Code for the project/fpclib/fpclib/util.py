# Author: Hamid Hamraz (hhamraz@cs.uky.edu)
# 2016, Department of Computer Science, University of Kentucky

import csv
import re
import random
import itertools
from operator import itemgetter
from constants import *
import geometry as gm
import numpy
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import pyplot as plt
import matplotlib.markers as markers
from matplotlib import cm as cm

def loadData(fpath, skipHeader=False):
	"""  Takes a tab/comma/space separated file path as the input including LiDAR points.
	    Reads all LiDAR points and returns a list of them.  """
	fin = open(fpath)
	if skipHeader: header = fin.readline()
	data = []
	for l in fin:
		r = decodeRecord(l)
		data.append(r)
	fin.close()
	print str(len(data)) + " data points loaded."
	return data

def writeData(fpath, data):
	""" Takes a file path and a list of records.
	# Writes the records, each in a line as comma separated, to the file path. """
	fout = open(fpath, 'w')
	rNum = len(data)
	for i, r in enumerate(data):
		l = len(r)
		for j, field in enumerate(r):
			fout.write(str(field))
			if j < l-1: fout.write(',')
		if i<rNum-1: fout.write('\n')
	fout.close()

def writeRecord(fout, r):
	if not r == None:
		fout.write(str(r[START]))
		for i in range(1, len(r)):
			fout.write("\t" + str(r[i]))
	fout.write("\n")


def decodeRecord(line):
	ls = re.split(r'[,;\t]', line)
	r = [None] * ELEMENT_NUM
	r[X] = float(ls[X])
	r[Y] = float(ls[Y])
	r[Z] = float(ls[Z])
	r[CLASS] = int(ls[CLASS])
	r[INTENSITY] = int(ls[INTENSITY])
	r[RETURN] = int(ls[RETURN])
	return r


def  appendToFile(s, fpath):
	""" Takes a string and writes it to the end of the file. """
	fout = open(fpath, 'a')
	fout.write(s)
	fout.close()

# A list of distinct colors to be used for making scatterplots
colors = ["green", "red", "blue", "lime", "yellow", "orange",
	"cyan", "magenta", "brown", "pink", "maroon", "teal", 
	"orangered", "olive", "chocolate", "rosybrown", "purple", "indigo", 
	"mediumblue", "darkkhaki", "grey", "coral", "thistle", "darkviolet", 
	"goldenrod", "sandybrown", "sienna", "saddlebrown", "tan", "springgreen", 
	"seagreen", "crimson", "chartreuse", "indianred", "wheat"]

def scatterPlot(trees, dim1, dim2, popup=True, fname="scatter.png"):
	""" Takes a list of trees (each tree is a list of LiDAR points) and two dimensions for visualization.
	 Plots the trees and either show a window or saves it to a file as directed by the third and 4th parameters.  """
	colCycle = itertools.cycle(colors)
	for i, t in enumerate(trees):
		x = []
		y = []
		for p in t:
			x.append(p[dim1])
			y.append(p[dim2])
		plt.scatter(x, y, color = next(colCycle), s=50)
	plt.axis('equal')
	if popup: plt.show()
	else: plt.savefig(fname)
		

def histogram(data, binNum = 10):
	plt.hist(data, bins=binNum)
	plt.show()


def outputPlotResult(trees, noise, fpath):
	fout = open(fpath, 'w')
	fout.write("Number of Trees:\t" + str(len(trees)) + '\n')
	fout.write("Number of Noise Segments:\t" + str(len(noise)) + '\n\n')
	for i, t in enumerate(trees):
		hull = gm.convexHull(t, X, Y)
		fout.write("Tree " + str(i+1) + '\n')
		fout.write("Boundary Points:\n")
		for p in hull:
			fout.write(str(p[X]) + ",\t" + str(p[Y]) + '\n')
		fout.write("Entire Set of Points:\n")
		for p in t:
			for j, val in enumerate(p):
				if j > ELEMENT_NUM: break
				fout.write(str(val) + '\t')
			fout.write('\n')
		fout.write("Tree End\n")
		

def loadLiveTreeData(fpath, plotNo, excludeNonLive = True):
	plotData = []
	with open(fpath) as csvFin: 
		reader = csv.DictReader(csvFin)  
		if plotNo < 0:
			for tree in reader:
				if not excludeNonLive or tree["Tree_Status"] == '1': plotData.append(tree)
			return plotData
		for tree in reader:
			if int(tree["Plot"]) == plotNo:
				if not excludeNonLive or tree["Tree_Status"] == '1':  
					plotData.append(tree)
		return plotData
		

def findOutliers(data, dispersement):
	""" finds the  outliers - points lying dispersement * IQR away to the sides of Q1 and Q3"""
	q1, q3 = numpy.percentile(data, [25.0, 75.0])
	iqr = q3 - q1
	lb = q1 - dispersement*iqr
	rb = q3 + dispersement*iqr
	l_outliers = []
	r_outliers = []
	for i, p in enumerate(data):
		if p < lb: l_outliers.append(i)
		elif p > rb: r_outliers.append(i)
	return l_outliers, r_outliers

def visualizeDataVSNoise(dsm, trees, collectedNoise):
	noise = []
	for n in collectedNoise:
		noise.extend(getDSMTreePoints(dsm, [n])[0])
	data = []
	for t in trees:
		data.extend(getDSMTreePoints(dsm, [t])[0])
	print "Data Size:", len(data) 
	print "Noise Size:", len(noise)
	scatterPlot([data, noise], X, Y)
	#scatterPlot([data, noise], X, Z)

def scatterPlot3D(trees, dim=Z):
	colCycle = itertools.cycle(colors)
	fig = plt.figure()
	ax = fig.add_subplot(111, projection='3d') 
	for i, t in enumerate(trees):
		x, y, z = [], [], []
		for p in t:
			x.append(p[X])
			y.append(p[Y])
			z.append(p[dim])
		ax.scatter(x, y, z, color = next(colCycle), marker = '.')
	ax.axis('equal')
	plt.show()

def surfacePlot(trees, dim=Z):
	colCycle = itertools.cycle(colors)
	fig = plt.figure()
	ax = fig.add_subplot(111, projection='3d') 
	for i, t in enumerate(trees):
		x, y, z = [], [], []
		for p in t:
			x.append(p[X])
			y.append(p[Y])
			z.append(p[dim])
		ax.plot_trisurf(x, y, z, color = next(colCycle))
	plt.axis('equal')
	plt.show()

def average(d, elmnt):
	sum = 0.0
	for  r in d:
		sum += r[elmnt]
	return sum/len(d)


